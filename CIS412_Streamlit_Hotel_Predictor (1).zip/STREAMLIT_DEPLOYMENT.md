# CIS 412 Streamlit Deployment

## Run on your computer

1. Install Python 3.10 or newer.
2. Open Terminal in the project folder.
3. Run `pip install -r requirements.txt`.
4. Run `streamlit run app.py`.

## Deploy to Streamlit Community Cloud

1. Create a GitHub repository (public, or private if supported by your Streamlit plan).
2. Upload `app.py`, `requirements.txt`, `Hotel Reservations.csv`, `hotel_cancellation_model.joblib`, and the `outputs` folder (at least `model_metrics.csv` and `tuning_results.json`) to the repository root.
3. Visit https://share.streamlit.io/ and sign in with GitHub.
4. Select **Create app**, choose your repository and branch, and set the main file path to `app.py`.
5. Click **Deploy**. Copy the public app URL for your CIS 412 presentation.

## Important

- The saved model was trained with scikit-learn. If you encounter a version-related unpickling error, recreate the model with the deployment environment's version of scikit-learn and recommit the `.joblib` file.
- The app does not retrain the model on every visitor request.
- The app is an educational demo, not a production booking decision system.
