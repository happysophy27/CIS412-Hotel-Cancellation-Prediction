"""CIS 412 | Hotel Reservation Cancellation Prediction — Streamlit app."""
from pathlib import Path
import calendar
import joblib
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
st.set_page_config(page_title="Hotel Cancellation Predictor", page_icon="🏨", layout="wide")
st.markdown('''<style>
.block-container {max-width:1100px;padding-top:2rem}
h1,h2,h3 {letter-spacing:-.025em}
[data-testid="stMetric"] {background:#f3f7fb;padding:16px;border-radius:12px}
.stButton>button[kind="primary"] {background:#1766a5;border-color:#1766a5}
</style>''', unsafe_allow_html=True)

@st.cache_resource
def load_model():
    return joblib.load(ROOT / "hotel_cancellation_model.joblib")

@st.cache_data
def load_data():
    return pd.read_csv(ROOT / "Hotel Reservations.csv")

try:
    model = load_model()
    df = load_data()
except Exception as exc:
    st.error(f"Could not load project files: {exc}")
    st.stop()

st.sidebar.title("🏨 CIS 412 Project")
page = st.sidebar.radio("Navigate", ["Predict Cancellation", "Dataset Overview", "Model Performance", "About the Project"])
st.sidebar.divider()
st.sidebar.caption("ASU CIS 412 · Hotel Reservation Cancellation Prediction")

if page == "Predict Cancellation":
    st.title("Hotel Reservation Cancellation Prediction")
    st.write("Enter reservation details to estimate the probability that a hotel booking will be canceled.")
    st.caption("Machine learning model: tuned Decision Tree classifier · Educational demonstration")
    with st.form("prediction_form"):
        st.subheader("Enter Booking Details")
        st.markdown("#### Reservation details")
        a,b,c = st.columns(3)
        with a:
            lead_time = st.slider("Lead time (days)", 0, int(df.lead_time.max()), 60, help="Days between booking and arrival")
            price = st.number_input("Average room price", min_value=0.0, max_value=10000.0, value=120.0, step=5.0)
            adults = st.number_input("Number of adults", min_value=0, max_value=20, value=2, step=1)
        with b:
            children = st.number_input("Number of children", min_value=0, max_value=15, value=0, step=1)
            weekend = st.number_input("Weekend nights", min_value=0, max_value=30, value=1, step=1)
            weekdays = st.number_input("Week nights", min_value=0, max_value=60, value=2, step=1)
        with c:
            requests = st.slider("Special requests", 0, int(df.no_of_special_requests.max()), 1)
            parking = st.selectbox("Parking space required?", ["No", "Yes"])
            repeat = st.selectbox("Repeated guest?", ["No", "Yes"])
        st.markdown("#### Booking category")
        d,e,f = st.columns(3)
        with d:
            meal = st.selectbox("Meal plan", sorted(df.type_of_meal_plan.unique()))
            market = st.selectbox("Market segment", sorted(df.market_segment_type.unique()))
        with e:
            room = st.selectbox("Room type", sorted(df.room_type_reserved.unique()))
            year = st.selectbox("Arrival year", sorted(df.arrival_year.unique().tolist()), index=len(df.arrival_year.unique())-1)
        with f:
            month = st.selectbox("Arrival month", list(range(1,13)), format_func=lambda x:calendar.month_name[x], index=5)
            day = st.selectbox("Arrival day", list(range(1,32)), index=14)
        st.markdown("#### Guest history")
        g,h = st.columns(2)
        with g:
            previous_cancellations = st.number_input("Previous cancellations", min_value=0, max_value=100, value=0, step=1)
        with h:
            previous_kept = st.number_input("Previous bookings not canceled", min_value=0, max_value=100, value=0, step=1)
        submitted = st.form_submit_button("Predict Cancellation Risk", type="primary", use_container_width=True)

    if submitted:
        if adults + children == 0:
            st.warning("Please enter at least one guest.")
        else:
            record = {
                "no_of_adults":adults,"no_of_children":children,
                "no_of_weekend_nights":weekend,"no_of_week_nights":weekdays,
                "type_of_meal_plan":meal,"required_car_parking_space":int(parking=="Yes"),
                "room_type_reserved":room,"lead_time":lead_time,
                "arrival_year":year,"arrival_month":month,"arrival_date":day,
                "market_segment_type":market,"repeated_guest":int(repeat=="Yes"),
                "no_of_previous_cancellations":previous_cancellations,
                "no_of_previous_bookings_not_canceled":previous_kept,
                "avg_price_per_room":price,"no_of_special_requests":requests,
                "total_nights":weekend+weekdays,
            }
            X = pd.DataFrame([record])[list(model.feature_names_in_)]
            probability = float(model.predict_proba(X)[0,1])
            st.divider()
            st.subheader("Prediction Result")
            left,right = st.columns([1,2])
            with left:
                st.metric("Estimated cancellation probability", f"{probability:.1%}")
                st.metric("Predicted outcome", "Canceled" if probability>=.5 else "Not canceled")
            with right:
                st.write("**Estimated cancellation risk**")
                st.progress(probability)
                if probability < .30:
                    st.success("Lower estimated risk")
                elif probability < .60:
                    st.warning("Moderate estimated risk")
                else:
                    st.error("Higher estimated risk")
                st.caption("Risk bands are illustrative, not calibrated operational thresholds. The model may be wrong.")
            st.info("Business use: consider proactive reminders and occupancy planning. Do not automatically reject bookings based on this score.")
            with st.expander("View model input record"):
                st.dataframe(X.T.rename(columns={0:"Value"}),use_container_width=True)

elif page == "Dataset Overview":
    st.title("Dataset Overview")
    n_cancel = int((df.booking_status=="Canceled").sum())
    a,b,c,d = st.columns(4)
    a.metric("Reservations",f"{len(df):,}")
    b.metric("Dataset columns",str(df.shape[1]))
    c.metric("Canceled",f"{n_cancel:,}")
    d.metric("Cancellation rate",f"{n_cancel/len(df):.1%}")
    st.subheader("Booking outcomes")
    st.bar_chart(df.booking_status.value_counts())
    st.subheader("Cancellation rate by lead time")
    bins=[-1,7,30,90,180,10000]
    labels=["0–7","8–30","31–90","91–180","181+"]
    tmp=df.assign(canceled=df.booking_status.eq("Canceled"),lead_group=pd.cut(df.lead_time,bins=bins,labels=labels))
    rates=tmp.groupby("lead_group",observed=True).canceled.mean().mul(100)
    st.bar_chart(rates)
    st.caption("Bars show observed cancellation percentages, not causal effects.")
    st.subheader("Sample records")
    st.dataframe(df.head(15),use_container_width=True)

elif page == "Model Performance":
    st.title("Model Performance")
    st.write("Model trained using an 80/20 stratified train-test split. Decision Tree hyperparameters were selected using 5-fold cross-validation on training data.")
    metrics_path=ROOT/"outputs"/"model_metrics.csv"
    tuning_path=ROOT/"outputs"/"tuning_results.json"
    if metrics_path.exists():
        metrics=pd.read_csv(metrics_path)
        st.subheader("Baseline model evaluation")
        st.dataframe(metrics.style.format({k:"{:.2%}" for k in ["accuracy","precision","recall","f1","roc_auc"]}),use_container_width=True)
    if tuning_path.exists():
        import json
        results=json.loads(tuning_path.read_text())
        st.subheader("Tuned Decision Tree — held-out test")
        cols=st.columns(4)
        for col,key,label in zip(cols,["test_accuracy","test_precision","test_recall","test_f1"],["Accuracy","Precision","Recall","F1 score"]):
            col.metric(label,f"{results[key]:.2%}")
        st.write("Selected hyperparameters:",results["best_params"])
    st.caption("These are historical hold-out results, not a guarantee of performance on new bookings.")

else:
    st.title("About This Project")
    st.write("**Business question:** Can we predict which hotel reservations are likely to be canceled before arrival?")
    st.write("**Approach:** CRISP-DM, exploratory analysis, preprocessing, Logistic Regression, Decision Tree, cross-validation and test evaluation.")
    st.write("**Target:** Canceled = 1; Not_Canceled = 0.")
    st.write("**Deployment:** Interactive demonstration using a saved scikit-learn pipeline.")
    st.warning("Educational prototype. Training data may not represent a particular hotel's future guests. Avoid using this tool as the sole basis for consequential decisions.")
